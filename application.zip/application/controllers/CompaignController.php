<?php 

class CompaignController extends CI_Controller {

    public function __construct(){
        parent:: __construct();
       // $this->load->model->();
       $this->load->model('Compaignmodel');
    } 

    public function invoiceview(){
        $this->load->view('invoice_view');
    }

    public function index(){
        $pageData['success'] = 0;
        $pageData['faild'] = 0;
        $pageData['progessTotal'] = 0;
        $this->db->order_by('id', 'desc');
        $query = $this->db->get('mail_history');
        $pageData['history'] = $query->result();
        $this->load->view('compaign',$pageData);
    }

    function getData(){
        $userid = $this->session->userdata('id');
        $data = $this->Compaignmodel->getGrafData($userid);
        //  print_r($data['successData']);die();
        echo json_encode($data);
    }

    public function saverecord(){
        $this->load->model('Compaignmodel');
        $userid = $this->session->userdata('id');
        $formArray = array();   
        $formArray['compainame'] = $this->input->post('compaigname');
        $formArray['comname'] = $this->input->post('cname');
        $formArray['comnum'] = $this->input->post('cnumer');
        $formArray['city'] = $this->input->post('country');
        $formArray['userid'] = $userid;
        $this->Compaignmodel->savedata($formArray);
        $this->session->set_flashdata('success','Record Added Succesfully!');
        redirect('CompaignController');
    }

    // public function sendMail(){
    //     $this->load->model('Compaignmodel');

    // }

    function sendMail(){
        $userid = $this->session->userdata('id');
        $smtpQuery = $this->db->query('SELECT * FROM smtp WHERE userid="'.$userid.'"');
        $smtp = $smtpQuery->result();
        $senderQuery = $this->db->query('SELECT * FROM sender WHERE userid="'.$userid.'"');
        $sender = $senderQuery->result();
        $subjectsQuery = $this->db->query('SELECT * FROM subjects WHERE userid="'.$userid.'"');
        $subjects = $subjectsQuery->result();
        $recipientQuery = $this->db->query('SELECT * FROM recipient WHERE userid="'.$userid.'"');
        $recipient = $recipientQuery->result();
        $bodylineQuery = $this->db->query('SELECT * FROM bodyline');
        $bodyline = $bodylineQuery->result();
        $uploasQuery =  $this->db->get('uploas');
        $uploads = $uploasQuery->result();
        $invoiceQuery =  $this->db->query('SELECT * FROM invoice WHERE  userid="'.$userid.'"' );
        $invoice = $invoiceQuery->result();
      // print_r($invoice);die();

        $htmlQuery =  $this->db->get('html');
        $htmlCon = $htmlQuery->result();
       

       

        $this->load->library('phpmailer_lib');
        // PHPMailer object
        $success = 1;
        $faild = 0;
        $a = 0; // smtp
        $b = 0; // sender name
        $c = 0; // subject
        $d = 0; // body line
        $e = 0; // uplods attechment
        $f = 0; // htmlCon
        $g = 0; // invoice
        $this->session->set_userdata('progessTotal',count($recipient));

       


        
        
        //code...
        for($sm = 0; $sm < count($recipient); $sm++){
           
       

            try {
                $pageData['k'] = $g;
                $pageData['fremail'] =  $smtp[$a]->username;
                $pageData['frname'] =  $sender[$b]->sendername;
                $pageData['toEmail'] =  $recipient[$sm]->recipient;
                $pageData['toName'] =  $sender[$b]->sendername;
                $pageData['invoice'] = $invoice;
                $htmlBody = $this->load->view('invoice_view',$pageData,true);

                    // print_r($htmlBody."</br>");
                $mail = $this->phpmailer_lib->load();
                // SMTP configuration
                $mail->isSMTP();
                $mail->SMTPAuth = true;
                $mail->Host     = $smtp[$a]->host;
                $mail->Username = $smtp[$a]->username;
                $mail->Password = $smtp[$a]->password;
                $mail->Port     = $smtp[$a]->port;
                $mail->SMTPSecure = 'tls';
                // print_r($mailSatus);
                try {
                    $validCredentials = $mail->SmtpConnect();
                  //  print_r("workign smtp" . $a."</br>");
                }
                catch(Exception $error) { //Returning False is  NOT an Exception.
                    //print_r("not working smtp ".$a."</br>");
                    $status = 0;
                    $this->saveHistory($status,$smtp[$a]->username,$recipient[$sm]->recipient,$subjects[$c]->subject);
                    $a++;
                    $faild++;
                    continue;
                }

                $mail->setFrom($smtp[$a]->username, $sender[$b]->sendername);
                $mail->Subject = $subjects[$c]->subject;
                $mail->addAddress($recipient[$sm]->recipient);
                // Set email format to HTML
                // Email body content
                $mailContent = $bodyline[$d]->bodyline;
                $postHtml = $this->input->post('html');
                $invoicepost = $this->input->post('invoice');
                $bodyLine = $this->input->post('bodyLine');
                $attechment = $this->input->post('attechment');
                if(isset($postHtml)){
                    $mail->Body = $htmlCon[$f]->htmlcode;
                    if(isset($invoicepost)){
                        $htmlBody = $htmlBody;
                    }else{
                        $htmlBody = "";
                    }

                    if(isset($attechment)){
                        $mail->addAttachment('assets/uploads/'.$uploads[$e]->image);
                    }
                }else{
                    
                }

                if(isset($invoice)){
                    $htmlBody = $htmlBody;
                }else{
                    $htmlBody = "";
                }

                if(isset($bodyLine)){
                    $mailContent = $mailContent;
                }else{
                    $mailContent = "";
                }

                if(isset($attechment)){
                    $mail->addAttachment('assets/uploads/'.$uploads[$e]->image);
                }

                if(isset($postHtml)){
                    $htmlcode = $htmlCon[$f]->htmlcode;
                }else{
                    $htmlcode = "";
                }
                
                $mail->Body = $htmlcode.'</br>'.$htmlBody.'</br>'.$mailContent;
            
                $mail->isHTML(true);
                //   print_r($mail);die();

                if(!$mail->send()){
                    continue;
                    $status = 0;
                    $this->session->set_flashdata('error',$faild++ . ' Mail Sending Error!');
                }else{
                    $status = 1;
                    $this->session->set_flashdata('success',$success++ . ' Mail Successfully Send!');
                    $this->session->set_flashdata('error',$faild . ' Mail Sending Error!');
                }        
                $this->saveHistory($status,$smtp[$a]->username,$recipient[$sm]->recipient,$subjects[$c]->subject);
                $a++;
                $b++;
                $c++;
                $d++;
                $e++;
                $f++;
                $g++;
                if(count($smtp) == $a){                                                                                         
                    $a=0;
                }   
                if(count($sender) == $b){
                    $b=0;
                }  
                if(count($subjects) == $c){
                    $c=0;
                }
                if(count($bodyline) == $d){
                    $d=0;
                }
                if(count($uploads) == $e){
                    $e=0;
                }
                if(count($htmlCon) == $f){
                    $f=0;
                }
                if(count($invoice) == $g){
                    $g=0;
                }          
           }catch(Exception $error) {
               $this->session->set_flashdata('error',$error->getMessage());
           }
          //  continue;
          //print_r($a."sonu</br>");
        }
        // die();
        redirect('CompaignController');
    }

    function saveHistory($status,$username,$recipient,$subject){
        $userid = $this->session->userdata('id');
        $data['status'] = $status;
        $data['sender_name'] = $username;
        $data['subject'] = $subject;
        $data['recipient'] = $recipient;    
        $data['user_id'] = $userid;
        $this->db->insert('mail_history',$data);
    }

    function delete(){
        $id = $this->input->post('id');
        // print_r($this->input->post('id'));die();
        if($id != 000){
            // single delete
            $this->db->where('id',$id);
            $this->db->delete('mail_history');
        }else{
            // all delete
            $this->db->truncate('mail_history');
        }
    }

    public function template(){
        if(isset($_POST['submit'])){
            $userid = $this->session->userdata('id');
            $formArray = array();
            $formArray['text1'] = $this->input->post('text1');
            $formArray['text2'] = $this->input->post('text2');
            $formArray['fname'] = $this->input->post('fname');
            $formArray['lname'] = $this->input->post('lname');
            $formArray['ganylisy'] = $this->input->post('ganylisy');
            $formArray['template'] = $this->input->post('template');
            $formArray['userid'] = $userid;
            $this->load->model('Compaignmodel');
            $tempdata = $this->Compaignmodel->checkrec($userid);
           if(Empty($tempdata)){
            $this->db->insert('template',$formArray);
            $this->session->set_flashdata('success','Record Added Succesfully!');
            redirect('CompaignController/template');
        }else{

            $this->Compaignmodel->updateerc($userid,$formArray);
            $this->session->set_flashdata('success','Record Updated Succesfully!');
            redirect('CompaignController/template');

        }
        }else{
            $this->load->view('template');
        }
    }

}
?>