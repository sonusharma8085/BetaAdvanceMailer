<?php 

class Compaignmodel extends CI_Model {

    public function savedata($formArray){
        $this->db->insert('emailist',$formArray);
    }

    public function checkrec($userid){
       $tempdata =  $this->db->query("SELECT * FROM `template` WHERE userid='$userid'");
       return $tempdata->result_array();
    }

    public function updateerc($userid,$formArray){
        $this->db->where('userid',$userid);                                                                         
        $this->db->update('template',$formArray);
    }

    public function livecompaign($userid){
      $live =   $this->db->query("SELECT * FROM `addlive` WHERE userid = '$userid'");
      return  $live->result_array();
    }

    function getGrafData($id){
        $array1 = ['user_id' => $id , 'status'=>'1'];
        $this->db->where($array1);
        $results = $this->db->get('mail_history');
        $result1 = $results->num_rows();

        $array2 = ['user_id' => $id , 'status'=>'0'];
        $this->db->where($array2);
        $resultf = $this->db->get('mail_history');
        $result2 = $resultf->num_rows();

        $res = ['successData' => $result1 , 'faildData'=>$result2];
        return $res;
    }

}

?>